import { Button } from "@/components/ui/button";
import { Product } from "@/lib/types";
import { Link } from "wouter";
import { toast } from "sonner";
import { ShoppingBag } from "lucide-react";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toast.success(`${product.name} added to bag`);
  };

  return (
    <div className="group flex flex-col bg-transparent">
      <Link href={`/product/${product.id}`}>
        <div className="relative aspect-[4/5] overflow-hidden mb-6 bg-secondary/20">
          <img 
            src={product.image} 
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          {/* Quick Add Overlay */}
          <div className="absolute inset-x-0 bottom-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-gradient-to-t from-black/20 to-transparent">
            <Button 
              onClick={handleAddToCart}
              className="w-full bg-white text-primary hover:bg-white/90 rounded-none h-12 flex gap-2"
            >
              <ShoppingBag className="h-4 w-4" />
              ADD TO BAG
            </Button>
          </div>
        </div>
      </Link>

      <div className="flex flex-col flex-1">
        <span className="text-[10px] uppercase tracking-[0.2em] text-foreground/40 mb-2">
          {product.category}
        </span>
        <div className="flex justify-between items-baseline mb-2">
          <h3 className="font-serif text-lg flex-1 mr-4">
            <Link href={`/product/${product.id}`} className="hover:text-accent transition-colors">
              {product.name}
            </Link>
          </h3>
          <span className="text-sm font-medium text-accent">${product.price}</span>
        </div>
        <p className="text-[13px] text-foreground/50 font-light line-clamp-2 leading-relaxed">
          {product.description}
        </p>
      </div>
    </div>
  );
}
