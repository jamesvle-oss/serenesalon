import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import heroImage from "@assets/generated_images/elegant_hands_with_natural_manicure.png";

export function Hero() {
  return (
    <section className="relative h-[90vh] w-full overflow-hidden flex items-center">
      {/* Background Image with Zoom effect */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImage} 
          alt="Serene Nails" 
          className="h-full w-full object-cover transform scale-105 animate-in fade-in zoom-in duration-1000" 
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-background/40 to-transparent" />
      </div>

      <div className="container mx-auto relative z-10 px-4 lg:px-8">
        <div className="max-w-2xl animate-in slide-in-from-left duration-1000 delay-300">
          <span className="uppercase tracking-[0.4em] text-[10px] font-semibold text-accent mb-4 block">
            Boutique Nail Studio
          </span>
          <h1 className="font-serif text-6xl md:text-8xl font-light leading-[1.1] mb-8 tracking-tight">
            The Art of <br />
            <span className="italic italic font-medium">Minimalism</span>
          </h1>
          <p className="text-lg text-foreground/70 font-light max-w-md mb-10 leading-relaxed">
            Experience elevated nail care in a space designed for tranquility. Curated products and bespoke services for the modern aesthetic.
          </p>
          <div className="flex flex-wrap gap-6">
            <Link href="/booking">
              <Button size="lg" className="bg-accent text-white hover:bg-accent/90 rounded-none px-10 py-6 uppercase tracking-widest text-xs h-auto">
                Book Appointment
              </Button>
            </Link>
            <Link href="/shop">
              <Button variant="outline" size="lg" className="border-primary text-primary hover:bg-primary hover:text-white rounded-none px-10 py-6 uppercase tracking-widest text-xs h-auto transition-all duration-300">
                Shop Collection
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce opacity-40">
        <span className="uppercase tracking-widest text-[9px] font-medium">Scroll</span>
        <div className="w-px h-12 bg-primary" />
      </div>
    </section>
  );
}
