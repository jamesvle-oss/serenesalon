import { Button } from "@/components/ui/button";
import { Service } from "@/lib/types";
import { Clock, ArrowRight } from "lucide-react";
import { Link } from "wouter";

interface ServiceCardProps {
  service: Service;
}

export function ServiceCard({ service }: ServiceCardProps) {
  return (
    <div className="group relative bg-white border border-border/40 p-8 hover:border-accent/40 transition-all duration-500 hover:shadow-2xl hover:shadow-accent/5">
      <div className="flex justify-between items-start mb-6">
        <div>
          <span className="text-[10px] uppercase tracking-[0.2em] text-accent font-bold mb-2 block">
            {service.category}
          </span>
          <h3 className="font-serif text-2xl group-hover:text-accent transition-colors">
            {service.title}
          </h3>
        </div>
        <div className="text-xl font-light font-serif">
          ${service.price}
        </div>
      </div>
      
      <p className="text-sm text-foreground/60 font-light leading-relaxed mb-8 min-h-[3rem]">
        {service.description}
      </p>

      <div className="flex items-center justify-between pt-6 border-t border-border/40">
        <div className="flex items-center text-xs text-foreground/40 gap-1.5 uppercase tracking-widest">
          <Clock className="h-3.5 w-3.5" />
          {service.duration}
        </div>
        <Link href="/booking">
          <Button variant="ghost" className="p-0 h-auto hover:bg-transparent text-accent flex gap-2 items-center text-xs uppercase tracking-widest font-bold">
            Book <ArrowRight className="h-3.5 w-3.5 transform group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </div>
    </div>
  );
}
