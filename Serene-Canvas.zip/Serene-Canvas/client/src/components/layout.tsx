import { Link, useLocation } from "wouter";
import { ShoppingBag, Menu, X, Instagram, Facebook } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function Layout({ children }: { children: React.ReactNode }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/services", label: "Services" },
    { href: "/shop", label: "Shop" },
    { href: "/contact", label: "Contact" },
  ];

  return (
    <div className="min-h-screen flex flex-col font-sans bg-background text-foreground">
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4 lg:px-8">
          <Link href="/">
            <a className="font-serif text-2xl font-bold tracking-[0.2em] text-primary hover:opacity-80 transition-opacity">
              SERENE
            </a>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-10">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <a className={cn(
                  "text-[13px] uppercase tracking-[0.15em] font-medium transition-colors hover:text-accent",
                  location === link.href ? "text-accent" : "text-foreground/70"
                )}>
                  {link.label}
                </a>
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-6">
            <Link href="/cart">
              <Button variant="ghost" size="icon" className="relative hover:bg-transparent">
                <ShoppingBag className="h-5 w-5 stroke-[1.5]" />
                <span className="absolute top-2 right-2 h-1.5 w-1.5 rounded-full bg-accent" />
              </Button>
            </Link>
            <Link href="/booking">
              <Button size="sm" className="bg-primary text-white hover:bg-primary/90 rounded-none px-6 uppercase tracking-widest text-[11px]">
                Book Now
              </Button>
            </Link>
          </div>
          
          {/* Mobile Menu Toggle */}
          <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu Overlay */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-16 left-0 w-full bg-background border-b border-border animate-in slide-in-from-top duration-300">
            <nav className="flex flex-col p-6 gap-4">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href}>
                  <a 
                    className="text-lg font-serif"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {link.label}
                  </a>
                </Link>
              ))}
              <Link href="/booking">
                <Button className="w-full mt-4 bg-accent text-white rounded-none">Book Appointment</Button>
              </Link>
            </nav>
          </div>
        )}
      </header>

      <main className="flex-1">
        {children}
      </main>

      <footer className="bg-primary text-primary-foreground pt-20 pb-10">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="md:col-span-2">
              <h2 className="font-serif text-3xl mb-6 tracking-wider">SERENE NAILS</h2>
              <p className="text-primary-foreground/70 max-w-sm font-light leading-relaxed">
                A sanctuary for refined nail care. We specialize in minimalist aesthetics and premium treatments that prioritize the health and beauty of your natural nails.
              </p>
            </div>
            <div>
              <h3 className="uppercase tracking-widest text-xs font-semibold mb-6">Salon</h3>
              <ul className="space-y-4 text-sm text-primary-foreground/70 font-light">
                <li>123 Serenity Way, Beauty Hills</li>
                <li>Mon-Fri: 10am — 8pm</li>
                <li>Sat-Sun: 9am — 6pm</li>
                <li>+1 (555) 123-4567</li>
              </ul>
            </div>
            <div>
              <h3 className="uppercase tracking-widest text-xs font-semibold mb-6">Follow Us</h3>
              <div className="flex gap-4">
                <a href="#" className="hover:text-accent transition-colors"><Instagram className="h-5 w-5" /></a>
                <a href="#" className="hover:text-accent transition-colors"><Facebook className="h-5 w-5" /></a>
              </div>
            </div>
          </div>
          <div className="border-t border-primary-foreground/10 pt-10 flex flex-col md:row justify-between items-center gap-4 text-[11px] uppercase tracking-widest text-primary-foreground/40">
            <p>© 2024 SERENE NAILS. ALL RIGHTS RESERVED.</p>
            <div className="flex gap-8">
              <a href="#" className="hover:text-primary-foreground">Privacy Policy</a>
              <a href="#" className="hover:text-primary-foreground">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
