import cuticleOil from "@assets/generated_images/minimalist_cuticle_oil_bottle.png";
import pressOns from "@assets/generated_images/luxury_press-on_nails_set.png";
import uvLamp from "@assets/generated_images/minimalist_uv_nail_lamp.png";
import { Product, Service } from "./types";

export const products: Product[] = [
  {
    id: "1",
    name: "Pure Nourish Cuticle Oil",
    price: 24,
    image: cuticleOil,
    category: "Treatments",
    description: "A blend of cold-pressed botanicals designed to strengthen and hydrate your nail beds."
  },
  {
    id: "2",
    name: "Classic Ombre Press-On Set",
    price: 38,
    image: pressOns,
    category: "Press-Ons",
    description: "Hand-painted minimalist ombre set with professional grade adhesive for a salon finish at home."
  },
  {
    id: "3",
    name: "Pro-Light UV LED Lamp",
    price: 85,
    image: uvLamp,
    category: "Hardware",
    description: "Minimalist, compact UV LED lamp for curing gel and press-on adhesive with precision."
  }
];

export const services: Service[] = [
  {
    id: "s1",
    title: "The Essential Manicure",
    price: 45,
    duration: "45 min",
    category: "Manicures",
    description: "Complete cuticle work, nail shaping, and a high-shine buff or non-toxic lacquer."
  },
  {
    id: "s2",
    title: "Signature Gel Polish",
    price: 65,
    duration: "60 min",
    category: "Manicures",
    description: "Long-lasting Japanese gel with precision application and nourishing prep."
  },
  {
    id: "s3",
    title: "Minimalist Nail Art",
    price: 85,
    duration: "90 min",
    category: "Nail Art",
    description: "Our signature 'clean girl' designs. Includes negative space, micro-french, or chrome finishes."
  }
];
