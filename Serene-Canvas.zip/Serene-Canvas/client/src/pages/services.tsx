import { Layout } from "@/components/layout";
import { services } from "@/lib/data";
import { ServiceCard } from "@/components/service-card";

export default function Services() {
  const categories = Array.from(new Set(services.map(s => s.category)));

  return (
    <Layout>
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-3xl mb-16">
            <span className="uppercase tracking-[0.3em] text-[10px] font-bold text-accent mb-4 block">
              The Menu
            </span>
            <h1 className="text-5xl md:text-6xl font-serif mb-8">Our Services</h1>
            <p className="text-lg text-foreground/60 font-light leading-relaxed">
              From essential maintenance to elaborate art, each service is performed with precision and care for your natural nail health.
            </p>
          </div>

          <div className="space-y-20">
            {categories.map(category => (
              <div key={category}>
                <h2 className="font-serif text-3xl mb-10 border-b border-border/40 pb-4 tracking-wider uppercase text-xs font-semibold text-foreground/40">{category}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {services.filter(s => s.category === category).map(service => (
                    <ServiceCard key={service.id} service={service} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}
