import { Layout } from "@/components/layout";
import { products } from "@/lib/data";
import { ProductCard } from "@/components/product-card";

export default function Shop() {
  return (
    <Layout>
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-3xl mb-16">
            <span className="uppercase tracking-[0.3em] text-[10px] font-bold text-accent mb-4 block">
              Global Commerce
            </span>
            <h1 className="text-5xl md:text-6xl font-serif mb-8">Curated Collection</h1>
            <p className="text-lg text-foreground/60 font-light leading-relaxed">
              Bring the Serene experience home with our hand-picked selection of nail care essentials and luxury press-ons.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-12 lg:gap-16">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}
