import { Layout } from "@/components/layout";
import { Hero } from "@/components/hero";
import { ServiceCard } from "@/components/service-card";
import { ProductCard } from "@/components/product-card";
import { services, products } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import salonInterior from "@assets/generated_images/modern_nail_salon_interior.png";

export default function Home() {
  return (
    <Layout>
      <Hero />

      {/* Services Spotlight */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <div className="max-w-xl">
              <span className="uppercase tracking-[0.3em] text-[10px] font-bold text-accent mb-4 block">
                Expert Care
              </span>
              <h2 className="text-4xl md:text-5xl font-serif leading-tight">
                Our Services are <br />
                <span className="italic">Designed for You</span>
              </h2>
            </div>
            <Link href="/services">
              <Button variant="link" className="text-primary hover:text-accent p-0 h-auto uppercase tracking-widest text-[11px] font-bold">
                View Full Menu
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </div>
      </section>

      {/* About Section with Image */}
      <section className="py-24 bg-secondary/10">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative aspect-[4/5] overflow-hidden">
              <img 
                src={salonInterior} 
                alt="Salon Interior" 
                className="w-full h-full object-cover shadow-2xl"
              />
              <div className="absolute -bottom-8 -right-8 bg-accent w-48 h-48 -z-10" />
            </div>
            <div className="lg:pl-10">
              <h2 className="font-serif text-4xl md:text-5xl mb-8 leading-tight">
                A Space of <br />
                <span className="italic font-medium">Serenity</span>
              </h2>
              <div className="space-y-6 text-foreground/70 font-light leading-relaxed">
                <p>
                  Located in the heart of Beauty Hills, Serene Nails was founded on the principle that nail care should be a restorative ritual, not just a maintenance task.
                </p>
                <p>
                  We use only premium, non-toxic products and employ meticulous techniques to ensure your nails remain healthy, strong, and beautiful. Our minimalist aesthetic reflects our philosophy: refined simplicity is the ultimate sophistication.
                </p>
              </div>
              <Button className="mt-12 bg-primary text-white rounded-none px-10 py-6 h-auto uppercase tracking-widest text-xs">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Trending Products */}
      <section className="py-24 bg-background overflow-hidden">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <span className="uppercase tracking-[0.3em] text-[10px] font-bold text-accent mb-4 block">
              Curated Selection
            </span>
            <h2 className="text-4xl md:text-5xl font-serif">Trending Products</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-24 border-t border-border/40">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl text-center">
          <h2 className="font-serif text-3xl md:text-4xl mb-6 tracking-wide">Join the Serene Society</h2>
          <p className="text-foreground/60 font-light mb-10 max-w-lg mx-auto">
            Subscribe to receive aesthetic inspiration, early access to new product drops, and beauty tips.
          </p>
          <div className="flex flex-col md:flex-row gap-4 max-w-md mx-auto">
            <input 
              type="email" 
              placeholder="YOUR EMAIL" 
              className="flex-1 bg-secondary/20 border-none px-6 py-4 text-xs tracking-widest focus:ring-1 focus:ring-accent outline-none uppercase"
            />
            <Button className="bg-primary text-white rounded-none px-8 py-4 h-auto uppercase tracking-widest text-xs">
              Subscribe
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
}
