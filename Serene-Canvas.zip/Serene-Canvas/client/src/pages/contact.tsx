import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export default function Contact() {
  return (
    <Layout>
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
            <div>
              <span className="uppercase tracking-[0.3em] text-[10px] font-bold text-accent mb-4 block">
                Connect With Us
              </span>
              <h1 className="text-5xl md:text-6xl font-serif mb-10">Get in Touch</h1>
              
              <div className="space-y-8 mb-16">
                <div className="flex gap-6">
                  <div className="w-12 h-12 bg-secondary/20 flex items-center justify-center">
                    <MapPin className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-serif text-xl mb-2">Location</h3>
                    <p className="text-foreground/60 font-light">123 Serenity Way, Beauty Hills, CA 90210</p>
                  </div>
                </div>

                <div className="flex gap-6">
                  <div className="w-12 h-12 bg-secondary/20 flex items-center justify-center">
                    <Clock className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-serif text-xl mb-2">Hours</h3>
                    <p className="text-foreground/60 font-light">Mon-Fri: 10am — 8pm<br />Sat-Sun: 9am — 6pm</p>
                  </div>
                </div>

                <div className="flex gap-6">
                  <div className="w-12 h-12 bg-secondary/20 flex items-center justify-center">
                    <Phone className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-serif text-xl mb-2">Contact</h3>
                    <p className="text-foreground/60 font-light">+1 (555) 123-4567<br />hello@serenenails.com</p>
                  </div>
                </div>
              </div>

              {/* Mock Map Placeholder */}
              <div className="aspect-video bg-secondary/30 relative flex items-center justify-center overflow-hidden border border-border/40">
                <div className="absolute inset-0 opacity-20 grayscale" style={{ backgroundImage: 'url(https://www.google.com/maps/d/u/0/thumbnail?mid=1Z_O-Y5G8Z4vL_7F2p6_v6B0H_Uo)' }} />
                <span className="relative font-serif text-foreground/40 tracking-widest uppercase text-xs">Google Maps Embed Placeholder</span>
              </div>
            </div>

            <div className="bg-secondary/10 p-10 lg:p-16">
              <h2 className="font-serif text-3xl mb-8">Send a Message</h2>
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest font-bold">Full Name</label>
                  <input type="text" className="w-full bg-background border-none px-6 py-4 text-xs tracking-widest focus:ring-1 focus:ring-accent outline-none" placeholder="YOUR NAME" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest font-bold">Email Address</label>
                  <input type="email" className="w-full bg-background border-none px-6 py-4 text-xs tracking-widest focus:ring-1 focus:ring-accent outline-none" placeholder="YOUR EMAIL" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest font-bold">Message</label>
                  <textarea rows={6} className="w-full bg-background border-none px-6 py-4 text-xs tracking-widest focus:ring-1 focus:ring-accent outline-none resize-none" placeholder="HOW CAN WE HELP?"></textarea>
                </div>
                <Button className="w-full bg-primary text-white rounded-none py-6 uppercase tracking-widest text-xs h-auto mt-4">
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
