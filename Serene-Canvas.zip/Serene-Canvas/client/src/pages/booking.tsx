import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";

export default function Booking() {
  return (
    <Layout>
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl text-center">
          <span className="uppercase tracking-[0.3em] text-[10px] font-bold text-accent mb-4 block">
            Reservations
          </span>
          <h1 className="text-5xl md:text-6xl font-serif mb-10">Book Your Ritual</h1>
          
          <div className="bg-white border border-border/40 p-1 lg:p-12 shadow-2xl shadow-accent/5">
            {/* Mock Calendly/GlossGenius Integration */}
            <div className="aspect-[4/5] md:aspect-video bg-secondary/10 flex flex-col items-center justify-center p-8 border border-dashed border-border/60">
              <h3 className="font-serif text-2xl mb-4">Scheduling Calendar</h3>
              <p className="text-foreground/40 font-light mb-8 max-w-sm">
                In a production environment, this section would host your Calendly or GlossGenius widget.
              </p>
              <div className="grid grid-cols-3 md:grid-cols-7 gap-4 w-full opacity-30">
                {Array.from({ length: 21 }).map((_, i) => (
                  <div key={i} className="aspect-square bg-primary/20 rounded-none" />
                ))}
              </div>
              <Button className="mt-12 bg-accent text-white rounded-none px-10 py-4 h-auto uppercase tracking-widest text-xs">
                Open Full Scheduler
              </Button>
            </div>
          </div>

          <div className="mt-16 text-foreground/50 font-light italic">
            <p>For groups or special event bookings, please contact us directly.</p>
          </div>
        </div>
      </section>
    </Layout>
  );
}
